Put the files into the following directories:

C:\Windows\System32 :
	-glfw3.dll
	-glew32.dll
	-glew32mx.dll
	
	
C:\Program Files (x86)\CodeBlocks\MinGW\include\GL :
	-glew.h
	-glxew.h
	-wglew.h
	-glfw3.h
	-glfw3native.h
	

C:\Program Files (x86)\CodeBlocks\MinGW\lib :
	-glew32.lib
	-glew32s.lib
	-glew32mx.lib
	-glew32mxs.lib
	-glfw3dll.a
	-libglfw3.a


In codeblocks editor go to Settings -> Compiler -> Linker Settings 
	- Add the following link libraries in this order:
	
		glew32s
		glew32
		libglfw3
		libopengl32
		glu32
		
		
Click Search Directories tab:

	-In Compiler tab add:
		C:\Program Files (x86)\CodeBlocks\MinGW\include
		
	-In Linker tab add:
		C:\Program Files (x86)\CodeBlocks\MinGW\lib
		

	For static linking, top of program needs:
	
	
	#define GLEW_STATIC
	#include <GL/glew.h>
	#include <GL/glfw3.h>


Now compile that trash. you are done. This was done on Windows 8.1 64bit with:
		GLEW 1.12
		GLFW 3..1 patched
		
		
-Shawn Sadler